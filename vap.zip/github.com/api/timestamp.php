<?php
    date_default_timezone_set('Greenwich Mean Time');
    echo $timestamp = date('H:i:s');