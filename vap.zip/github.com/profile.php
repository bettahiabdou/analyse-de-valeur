<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from github.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 24 Sep 2017 20:47:30 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8"/><!-- /Added by HTTrack -->
<head>
	
	<title>Cloud-VAP | Verify email</title>
	<?php include 'head.html'; ?>
</head>

<body class="logged-out env-production page-responsive min-width-0">
	<div role="main">
<?php include 'api/navbar.php'; ?>
			<div class="row" style=" background-color: black; color: white; height: 100px; margin-top: 60px;">
				<div class="col-md-8 col-md-offset-2"><br>
					<h2 class="alt-h1 text-white lh-condensed-ultra text-center " style="color: white;">Hello  <?=$_SESSION['nomMembre'] ?>, This is your Profile
					</h2>
					<br>
				</div>
			</div>
</div>
<?php include 'footer.html'; ?>


</body>

<!-- Mirrored from github.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 24 Sep 2017 20:47:54 GMT -->
</html>

