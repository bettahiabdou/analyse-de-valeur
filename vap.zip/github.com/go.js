document.write('<script src="../gojs/release/go.js"></script>');
